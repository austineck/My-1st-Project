1. Be able to add items to a to-do list.
2. Be able to view items on a to-do list.
3. Be able to add an identifer that marks items complete.
